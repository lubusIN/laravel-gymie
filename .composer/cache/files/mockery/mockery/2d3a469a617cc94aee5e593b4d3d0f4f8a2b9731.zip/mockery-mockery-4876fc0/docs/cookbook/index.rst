Cookbook
========

.. toctree::
    :hidden:

    default_expectations
    detecting_mock_objects
    mocking_hard_dependencies

.. include:: map.rst.inc
