<?php
error_reporting(E_ALL | E_STRICT);

session_start();
