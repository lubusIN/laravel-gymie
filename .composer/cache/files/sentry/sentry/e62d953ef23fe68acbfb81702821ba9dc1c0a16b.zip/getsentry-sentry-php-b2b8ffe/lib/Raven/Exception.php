<?php
class Raven_Exception extends Exception
{
}
