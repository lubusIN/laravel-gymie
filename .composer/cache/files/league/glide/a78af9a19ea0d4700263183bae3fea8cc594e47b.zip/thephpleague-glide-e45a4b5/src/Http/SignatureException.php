<?php

namespace League\Glide\Http;

use Exception;

class SignatureException extends Exception
{
}
