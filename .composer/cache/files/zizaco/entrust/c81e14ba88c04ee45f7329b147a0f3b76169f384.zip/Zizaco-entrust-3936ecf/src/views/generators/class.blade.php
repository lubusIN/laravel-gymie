<?php echo '<?php' ?> namespace App;

use Zizaco\Entrust\Entrust<?php echo $class ?>;

class <?php echo $class ?> extends Entrust<?php echo $class ?>
{
}
