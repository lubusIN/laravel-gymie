<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class MediaIsNotPartOfCollection extends Exception
{
}
