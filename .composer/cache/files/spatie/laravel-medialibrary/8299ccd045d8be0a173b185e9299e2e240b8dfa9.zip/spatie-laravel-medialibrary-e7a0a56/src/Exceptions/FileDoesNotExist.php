<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class FileDoesNotExist extends Exception
{
}
