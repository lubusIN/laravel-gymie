<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class InvalidConversionParameter extends Exception
{
}
