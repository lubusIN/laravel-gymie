<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class UnknownConversion extends Exception
{
}
