<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class UrlCouldNotBeDetermined extends Exception
{
}
