<?php

namespace Spatie\MediaLibrary\Jobs;

use Illuminate\Bus\Queueable;

abstract class Job
{
    use Queueable;
}
