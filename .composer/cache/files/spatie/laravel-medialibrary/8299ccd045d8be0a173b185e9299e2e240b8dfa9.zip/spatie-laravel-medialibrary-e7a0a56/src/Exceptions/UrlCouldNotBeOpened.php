<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class UrlCouldNotBeOpened extends Exception
{
}
