<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class InvalidNewOrder extends Exception
{
}
