<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class FileTooBig extends Exception
{
}
