<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class FileCannotBeImported extends Exception
{
}
