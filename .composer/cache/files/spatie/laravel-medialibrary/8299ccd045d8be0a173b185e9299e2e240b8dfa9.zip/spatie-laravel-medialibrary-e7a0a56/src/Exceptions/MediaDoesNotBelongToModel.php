<?php

namespace Spatie\MediaLibrary\Exceptions;

use Exception;

class MediaDoesNotBelongToModel extends Exception
{
}
