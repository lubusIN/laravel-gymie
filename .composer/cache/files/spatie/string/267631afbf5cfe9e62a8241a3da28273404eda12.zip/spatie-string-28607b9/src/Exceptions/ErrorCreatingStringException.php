<?php

namespace Spatie\String\Exceptions;

use Exception;

class ErrorCreatingStringException extends Exception
{
}
