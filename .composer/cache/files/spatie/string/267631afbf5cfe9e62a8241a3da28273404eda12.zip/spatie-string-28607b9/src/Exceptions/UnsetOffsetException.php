<?php

namespace Spatie\String\Exceptions;

use Exception;

class UnsetOffsetException extends Exception
{
}
