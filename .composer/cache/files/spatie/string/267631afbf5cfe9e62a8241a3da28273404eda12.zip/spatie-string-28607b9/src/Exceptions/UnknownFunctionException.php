<?php

namespace Spatie\String\Exceptions;

use Exception;

class UnknownFunctionException extends Exception
{
}
