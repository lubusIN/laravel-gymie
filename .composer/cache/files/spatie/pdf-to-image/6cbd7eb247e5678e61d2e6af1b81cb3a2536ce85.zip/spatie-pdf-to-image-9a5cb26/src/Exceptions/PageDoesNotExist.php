<?php

namespace Spatie\PdfToImage\Exceptions;

class PageDoesNotExist extends \Exception
{
}
