<?php

namespace Spatie\PdfToImage\Exceptions;

class PdfDoesNotExist extends \Exception
{
}
