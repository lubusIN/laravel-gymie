<?php

namespace Spatie\PdfToImage\Exceptions;

class InvalidFormat extends \Exception
{
}
