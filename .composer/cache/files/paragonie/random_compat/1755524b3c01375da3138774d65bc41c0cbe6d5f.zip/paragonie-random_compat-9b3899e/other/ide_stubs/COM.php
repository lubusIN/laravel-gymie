<?php
/**
 * Class COM
 *
 * This is just a stub class.
 */
class COM
{
    /**
     * This is just a dummy function to make IDE autocomplete less insane.
     *
     * @param int $bytes
     * @param int $dummy
     * @return string
     */
    public function GetRandom($bytes, $dummy)
    {
        return '';
    }
}
