<?php

namespace Sofa\Eloquence\Mutator;

class InvalidCallableException extends \LogicException
{

}
