<?php

namespace Sofa\Eloquence\Metable;

class InvalidTypeException extends \InvalidArgumentException
{

}
