<?php

namespace Sofa\Eloquence\Metable;

class InvalidMutatorException extends \LogicException
{

}
