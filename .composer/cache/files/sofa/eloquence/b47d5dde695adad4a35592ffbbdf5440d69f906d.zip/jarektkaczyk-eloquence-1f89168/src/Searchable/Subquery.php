<?php

namespace Sofa\Eloquence\Searchable;

use Sofa\Eloquence\Subquery as BaseSubquery;

class Subquery extends BaseSubquery
{

}
