<?php

namespace Sofa\Eloquence\Searchable;

interface Searchable
{

}
