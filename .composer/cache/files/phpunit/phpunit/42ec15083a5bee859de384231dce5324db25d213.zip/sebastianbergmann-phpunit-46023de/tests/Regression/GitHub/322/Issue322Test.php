<?php
class Issue322Test extends PHPUnit_Framework_TestCase
{
    /**
     * @group one
     */
    public function testOne()
    {
    }

    /**
     * @group two
     */
    public function testTwo()
    {
    }
}
