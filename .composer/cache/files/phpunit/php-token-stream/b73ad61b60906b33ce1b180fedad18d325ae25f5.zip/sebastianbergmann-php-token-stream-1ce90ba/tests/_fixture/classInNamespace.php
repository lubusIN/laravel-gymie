<?php
namespace Foo\Bar;

class TestClass
{
}
